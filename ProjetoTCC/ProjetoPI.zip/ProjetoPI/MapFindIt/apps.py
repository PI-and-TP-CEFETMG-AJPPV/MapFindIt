from django.apps import AppConfig


class MapfinditConfig(AppConfig):
    name = 'MapFindIt'
