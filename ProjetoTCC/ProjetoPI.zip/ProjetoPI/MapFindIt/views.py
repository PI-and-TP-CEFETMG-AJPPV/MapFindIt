# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

def home(request):
    if request.method=="GET":
	if request.GET.__contains__("primNome"):
	   return render(request, 'MapFindIt/cadastro.html', {})     
	else:
	   if request.GET.__contains__("email"):
 	   	return render(request, 'MapFindIt/logar.html', {})
           else:
		return render(request, 'MapFindIt/home.html', {})
    else:
    	return render(request, 'MapFindIt/home.html', {})
