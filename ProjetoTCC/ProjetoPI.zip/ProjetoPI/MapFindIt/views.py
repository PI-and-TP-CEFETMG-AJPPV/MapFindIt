from __future__ import unicode_literals

from django.shortcuts import render
import md5
from .models import Usuario

def home(request):
	if request.method=="POST":
		if request.POST.__contains__("primNome"):
			usuario = Usuario.objects.create(primnomeusuario=request.POST.get('primNome'), ultnomeusuario=request.POST.get('ultimoNome'), emailusuario=request.POST.get('email'), senhausuario=md5.new(request.POST.get('password')+'cockles'), datanascimento=request.POST.get('nascimento'), idtsexo=request.POST.get('gender')[:1])
	   		usuario.save()
			return render(request, 'MapFindIt/cadastro.html', {})     
		else:
			if request.POST.__contains__("email"):
				usuarios = Usuario.objects.filter(emailusuario=request.POST.get('email')).filter(senhausuario=md5.new(request.POST.get('senha')+'cockles'))
				return render(request, 'MapFindIt/logar.html', {'usuarios': usuarios})
			else:
				return render(request, 'MapFindIt/home.html', {})
	else:
		return render(request, 'MapFindIt/home.html', {})
